sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("RM868203.Miti.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map