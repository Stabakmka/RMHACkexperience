sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("RM868203.RMapp.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map